
import Header from "../components/header";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
export default function Ajouter(props){
    let navigate = useNavigate();
    let [id,setId]=useState("")
    let [nom,setNom]=useState("")
    let [prenom,setPrenom]=useState("")
    let [tele,setTele]=useState("")
    function ajouterC(){
        let contact={id:id,nom:nom,prenom:prenom,telephone:tele}
        props.ajouter(contact)
        navigate('/contacts')
    }
    return(
        <>
            <Header/>
            <label>ID</label>
            <input type="number" value={id} onChange={(e)=>setId(e.target.value)}/>
            <br></br>
            <label>Nom</label>
            <input type="text" value={nom} onChange={(e)=>setNom(e.target.value)}/>
            <br></br>
            <label>Prénom</label>
            <input type="text" value={prenom} onChange={(e)=>setPrenom(e.target.value)}/>
            <br></br>
            <label>Téléphone</label>
            <input type="text" value={tele} onChange={(e)=>setTele(e.target.value)}/>
            <br></br>
            <button onClick={ajouterC}>Ajouter</button>
        </>
    )
}

import {Link} from "react-router-dom";
import Header from "../components/header";
export default function Home(){
    return(
        <>
            <Header/>
            <h1>Bienvenu dans la page d'acceuil</h1>
            <h2>Pour voir la liste des contacts <Link to="/contacts">cliquer ici</Link></h2>
        </>
    )
}
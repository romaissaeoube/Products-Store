import { Link } from "react-router-dom";
import Header from "../components/header";
export default function Contacts(props){
    return(
        <>
            <Header/>
            <table>
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Téléphone</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                    {props.contacts.map((c)=>
                        <tr key={c.id}>
                            <td>{c.id}</td>
                            <td>{c.nom}</td>
                            <td>{c.prenom}</td>
                            <td>{c.telephone}</td>
                            <td>
                                <Link to={"/editer/" + c.id}>Modifier</Link>
                                <button onClick={()=>props.supprimer(c.id)}>Supprimer</button>
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </>
    )
}

import Header from "../components/header";
import { useState ,useEffect} from "react";
import { useParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";
export default function Editer(props){
    let {id}=useParams();
    let navigate = useNavigate();
    let [nom,setNom]=useState("")
    let [prenom,setPrenom]=useState("")
    let [tele,setTele]=useState("")
    useEffect(()=>{
        let contact = props.contacts.find((c)=> c.id === id);
        if(contact){
            setNom(contact.nom);
            setPrenom(contact.prenom);
            setTele(contact.telephone);
        }
    },[id,props.contacts]);
    function modifierC(){
        let Ncontact={id:id,nom:nom,prenom:prenom,telephone:tele}
        props.modifier(Ncontact)
        navigate('/contacts')
    }
    return(
        <>
            <Header/>
            <label>ID</label>
            <input type="text" value={id} disabled/>
            <br/>
            <label>Nom</label>
            <input type="text" value={nom} onChange={(e)=>setNom(e.target.value)}/>
            <br/>
            <label>Prénom</label>
            <input type="text" value={prenom} onChange={(e)=>setPrenom(e.target.value)}/>
            <br/>
            <label>Téléphone</label>
            <input type="text" value={tele} onChange={(e)=>setTele(e.target.value)}/>
            <br/>
            <button onClick={modifierC}>Enregistrer</button>
        </>
    )
}

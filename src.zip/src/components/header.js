import { Link } from "react-router-dom";

export default function Header(){
    return(
        <>
            <nav className="nav navbar bg-dark">
                <li>
                    <Link to="/">Acceuil</Link>
                </li>
                <li>
                    <Link to="/contacts">Contacts</Link>
                </li>
                <li>
                    <Link to= '/ajouter'>Ajouter un Contact</Link>
                </li>
            </nav>
        </>
    )
}